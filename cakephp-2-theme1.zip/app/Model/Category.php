<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Category extends AppModel {
public $actsAs = array(
        'Tree'
    );
}
