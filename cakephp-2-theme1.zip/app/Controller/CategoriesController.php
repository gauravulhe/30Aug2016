<?php
App::uses('AppController', 'Controller');
/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class CategoriesController extends AppController {

	public function index(){
		$data = $this->Category->generateTreeList(
			null,
			null,
			null
		);
		debug($data);exit;
	}

}