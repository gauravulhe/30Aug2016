<?php

class Image extends BrownieAppModel{

	public $name = 'Image';
	public $useTable = false;

}