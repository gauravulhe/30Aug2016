<?php
App::uses('UserModel', 'Model');

/**
 * UserModel Test Case
 */
class UserModelTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.user_model'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->UserModel = ClassRegistry::init('UserModel');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->UserModel);

		parent::tearDown();
	}

}
