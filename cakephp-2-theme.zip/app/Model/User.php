<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class User extends AppModel {
public $actsAs = array(
        'Search.Searchable',
        'Upload.Upload' => array(
            'avatar1' => array(
                'fields' => array(
                    'dir' => 'photo_dir'
                )
            )
        )
    );
}
