<?php
App::uses('AppModel', 'Model');
/**
 * UserModel Model
 *
 */
class UserModel extends AppModel {

}
