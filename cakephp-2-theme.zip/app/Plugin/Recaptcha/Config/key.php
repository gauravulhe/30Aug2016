<?php

$config = array(
	'Recaptcha' => array(
		'Public'  => '6Ld7DykTAAAAALoNqJxqfWUoGQE2S65rFfikHP99',
		'Private' => '6Ld7DykTAAAAABBnub5mn7xhoLzPow0wfH1QnZKp',
	),
);

?>
