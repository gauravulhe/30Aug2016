<?php
class FileUploadAppModel extends AppModel {
  
}
?>