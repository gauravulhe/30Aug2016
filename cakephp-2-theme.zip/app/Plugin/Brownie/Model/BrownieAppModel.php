<?php

class BrownieAppModel extends AppModel {

	public $actsAs = array('Containable');

}