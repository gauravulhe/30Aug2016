FileImportBehavior
------------------

``FileImportBehavior`` may be used to import files directly from the
disk. This is useful in importing from a directory already on the
filesystem.
