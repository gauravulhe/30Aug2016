<?php
App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
/**
 * Members Controller
 *
 * @property Member $Member
 * @property PaginatorComponent $Paginator
 */
class MembersController extends AppController {


/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Search.Prg');
	public $uses = array('Member', 'Country', 'State', 'City', 'Community', 'Gotra');

	public function beforeFilter(){
		parent::beforeFilter();
		$this->Auth->allow('add', 'index', 'status', 'ajax_load_state', 'ajax_load_city', 'ajax_load_state_new', 'ajax_load_city_new', 'ajax_load_gotra', 'ajax_load_other_gotra');
	}


/*
	authorized member
*/

	public function isAuthorized($user){

		// allow all user to add
		if (in_array($this->action, array('add', 'view'))) {
			return true;
		}

		// allow admin to edit and delete
		if (in_array($this->action, array('edit', 'delete'))) {
			$dataId = $this->request->params['pass'][0];
			$memberId = $this->Auth->user('id');
			if ($this->isOwnedBy($dataId, $memberId)) {
				return true;
			}
			return false;
		 }
	}

	public function isOwnedBy($dataId, $memberId){
		return $this->Member->field('id', array('id' => $dataId, 'id' => $memberId)) !== false;
	}

/*
login method
*/

	public function login(){
		if($this->request->is('post')){

			if ($this->Auth->login()) {
				//debug($this->Auth->user('status'));exit;
				$status = $this->Auth->user('status');
				if ($status != 0) {
					return $this->redirect($this->Auth->redirectUrl());
				}else{
					$this->Flash->success(__('Your account is not activated yet.'));
					$this->redirect(array('action' => 'logout'));
				}

			}else{
				return $this->Flash->error('Failed to login');
			}
		}
	}

/*
login method
*/

	public function logout(){
		return $this->redirect($this->Auth->logout());
	}


/*
change status of member
*/

	public function status($id = null){
		if (!$this->Member->exists($id)) {
			throw new Exception(__('Invalid Member'));
		}
		$member = $this->Member->find('first', array('conditions' => array('Member.id' => $id)));
		$memberId = $member['Member']['id'];

		$this->Member->id = $memberId;
		if($this->Member->saveField('status', '1')){
			$this->redirect(array('action' => 'login'));
		}
	}


/**
 * index method
 *
 * @return void
 */
	public function index() {

		if (empty($this->request->data)) {
			$this->Member->recursive = 0;
			$this->set('members', $this->Paginator->paginate());
		}else{
			$username = $this->request->data['Member']['username'];
			$name = $this->request->data['Member']['name'];
			$gender = $this->request->data['Member']['gender'];
			$age1 = $this->request->data['Member']['age1'];
			$age2 = $this->request->data['Member']['age2'];
			$conditions = array(
					'Member.username LIKE' => '%'.$username.'%',
					'Member.name LIKE' => '%'.$name.'%',
					'Member.gender LIKE' => '%'.$gender.'%',
					'Member.age BETWEEN ? AND ?' => array($age1, $age2)
			);
			$member = $this->Member->find('all', array('conditions' => $conditions ));
			$this->set('members', $member, $this->Paginator->paginate());
		}



					//debug($this->request);exit;
	        // $this->Prg->commonProcess();
	        // $this->Paginator->settings['conditions'] = $this->Member->parseCriteria($this->Prg->parsedParams());
	        // $this->set('members', $this->Paginator->paginate());

	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Member->exists($id)) {
			throw new NotFoundException(__('Invalid member'));
		}
		$options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
		$this->set('member', $this->Member->find('first', $options));

		// country code
		$code = $this->Member->find('first', array('conditions' => array('Member.id' => $id), array('fields' => array('Member.country_id', 'Member.state_id', 'Member.city_id'))));

		$countries = $this->Country->find('first', array('conditions' => array('Country.id' => $code['Member']['country_id']), 'fields' => 'Country.country'));
		$this->set('country', $countries['Country']['country']);

		// state code
		$states = $this->State->find('first', array('conditions' => array('State.id' => $code['Member']['state_id']), 'fields' => 'State.state'));
		$this->set('state', $states['State']['state']);

		// city code
		$cities = $this->City->find('first', array('conditions' => array('City.id' => $code['Member']['city_id']), 'fields' => 'City.city'));
		$this->set('city', $cities['City']['city']);

	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			//debug($this->request->data['Member']);exit;
			$this->Member->create();
			if ($data = $this->Member->save($this->request->data)) {

				//debug($data);
				$memberId = $data['Member']['id'];
				$statusUrl = 'http://localhost/gaurav/cakephp/cakephp-2-theme/Members/status/'.$memberId;
				//debug($data['Member']['id']);exit;
				//$to = $this->request->data['Member']['username'];
				$Email = new CakeEmail();
				$Email->from(array('gauravulhe8@gmail.com' => 'My login'));
				$Email->to('gauravulhe24@gmail.com');
				$Email->subject('This is test mail');
				$Email->send($statusUrl);

				$this->Flash->success(__('The member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The member could not be saved. Please, try again.'));
			}
		}

		$countries = $this->Country->find('list', array('fields' => array('id', 'country')));
		$this->set('country', $countries);

		$states = $this->State->find('list', array('fields' => array('id', 'state')));
		$this->set('state', $states);

		$cities = $this->City->find('list', array('fields' => array('id', 'city')));
		$this->set('city', $cities);

		$communities = $this->Community->find('list', array('fields' => array('id', 'samaj')));
		$this->set('community', $communities);
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		//debug($this->request);
		if ($this->Auth->user('id') != $this->request->params['pass'][0]) {
			return $this->redirect(array('action' => 'index'));
		}
		if (!$this->Member->exists($id)) {
			throw new NotFoundException(__('Invalid member'));
		}
		if ($this->request->is(array('post', 'put'))) {

			if (!empty($this->request->data['Member']['avatar1'] || $this->request->data['Member']['avatar2'] || $this->request->data['Member']['avatar3'] || $this->request->data['Member']['avatar4'])) {
				$this->request->data['Member']['avatar1'] = $this->request->data['Member']['avatar1'];
				$this->request->data['Member']['avatar2'] = $this->request->data['Member']['avatar2'];
				$this->request->data['Member']['avatar3'] = $this->request->data['Member']['avatar3'];
				$this->request->data['Member']['avatar4'] = $this->request->data['Member']['avatar4'];
			}else{
				$this->request->data['Member']['avatar1'] = $this->request->data['Member']['avatar1_old'];
				$this->request->data['Member']['avatar2'] = $this->request->data['Member']['avatar2_old'];
				$this->request->data['Member']['avatar3'] = $this->request->data['Member']['avatar3_old'];
				$this->request->data['Member']['avatar4'] = $this->request->data['Member']['avatar4_old'];
			}
			//debug($this->request->data);exit;
			if ($this->Member->save($this->request->data)) {
				$this->Flash->success(__('The member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The member could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
			$this->request->data = $this->Member->find('first', $options);
			$this->set('member', $this->request->data);
			// State, City Id
			$code = $this->Member->find('first', array('conditions' => array('Member.id' => $id), array('fields' => array('Member.country_id', 'Member.state_id', 'Member.city_id', 'Member.community', 'Member.gotra_id', 'Member.other_gotra_id'))));

			$countries = $this->Country->find('list', array('fields' => array('id', 'country')));
			$this->set('country', $countries);

			$countryId = $code['Member']['country_id'];
			$states = $this->State->find('list', array('conditions' => array('State.country_id' => $countryId), 'fields' => array('id', 'state')));
			$this->set('state', $states);

			$stateId = $code['Member']['state_id'];
			$cities = $this->City->find('list', array('conditions' => array('City.state_id' => $stateId), 'fields' => array('id', 'city')));
			$this->set('city', $cities);

			$communities = $this->Community->find('list', array('fields' => array('id', 'samaj')));
			$this->set('community', $communities);

			$gotraId = $code['Member']['community_id'];
			$gotra = $this->Gotra->find('list', array('conditions' => array('Gotra.community_id' => $gotraId), 'fields' => array('id', 'gotra')));
			$this->set('gotra', $gotra);
			$this->set('other_gotra', $gotra);
		}

	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Member->id = $id;
		if (!$this->Member->exists()) {
			throw new NotFoundException(__('Invalid member'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Member->delete()) {
			$this->Flash->success(__('The member has been deleted.'));
		} else {
			$this->Flash->error(__('The member could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}


	/**
	 * delete method
	 *
	 * @throws NotFoundException
	 * @param string $id
	 * @return void
	 */
		public function delete_avatar($id = null) {
			$this->Member->id = $id;
			if (!$this->Member->exists()) {
				throw new NotFoundException(__('Invalid member'));
			}
			$this->request->allowMethod('post', 'delete');
			if ($this->Member->delete()) {
				$this->Flash->success(__('The member has been deleted.'));
			} else {
				$this->Flash->error(__('The member could not be deleted. Please, try again.'));
			}
			return $this->redirect(array('action' => 'index'));
		}


/*
	ajax load state method
*/

	public function ajax_load_state($country_id){
		if (!empty($country_id)) {

			$states = $this->State->find('list', array('conditions' => array('State.country_id' => $country_id), 'fields' => array('State.id', 'State.state')));

			$data = '';

			if (!empty($states)) {

				$data .= '<select name="data[Member][state_id]" id="state_id" onchange="load_city(this.value);" required="required" style="width:240px;">';
				$data .= "<option value=''>Select</option>";

				foreach ($states as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';

			}else{
				$data .= '<select name="data[Member][state_id]" id="state_id" onchange="load_city(this.value);" required="required" style="width:240px;">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load state new method
*/

	public function ajax_load_state_new($country_id){
		debug($country_id);
		if (!empty($country_id)) {

			$states = $this->State->find('list', array('conditions' => array('State.country_id' => $country_id), 'fields' => array('State.id', 'State.state')));

			$data = '';

			if (!empty($states)) {

				$data .= '<select name="data[Member][new_state]" id="state_id" onchange="load_city_new(this.value);" required="required" style="width:240px;">';
				$data .= "<option value=''>Select</option>";

				foreach ($states as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';

			}else{
				$data .= '<select name="data[Member][new_state]" id="state_id" onchange="load_city_new(this.value);" required="required" style="width:240px;">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load city method
*/

	public function ajax_load_city($state_id){
		if (!empty($state_id)) {

			$cities = $this->City->find('list', array('conditions' => array('City.state_id' => $state_id), 'fields' => array('City.id', 'City.city')));

			$data = '';

			if (!empty($cities)) {

				$data .= '<select name="data[Member][city_id]" id="city_id" required="required" style="width:240px;">';
				$data .= "<option value=''>Select</option>";

				foreach ($cities as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';

			}else{
				$data .= '<select name="data[Member][city_id]" id="city_id" required="required" style="width:240px;">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load gotra method
*/

	public function ajax_load_gotra($community_id){
		if (!empty($community_id)) {

			$gotras = $this->Gotra->find('list', array('conditions' => array('Gotra.community_id' => $community_id), 'fields' => array('Gotra.id', 'Gotra.gotra')));

			$data = '';

			if (!empty($gotras)) {

				$data .= '<select name="data[Member][gotra_id]" id="gotra_id" onchange="load_other_gotra(this.value);" required="required" style="width:240px;">';
				$data .= "<option value=''>Select</option>";

				foreach ($gotras as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';

			}else{
				$data .= '<select name="data[Member][gotra_id]" id="gotra_id" required="required" style="width:240px;">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load other gotra method
*/

	public function ajax_load_other_gotra($gotra_id){
		if (!empty($gotra_id)) {

			$communityId = $this->Gotra->find('first', array('conditions' => array('Gotra.id' => $gotra_id), 'fields' => array('community_id')));
			$community_id = $communityId['Gotra']['community_id'];

			$gotras = $this->Gotra->find('list', array('conditions' => array('Gotra.community_id' => $community_id), 'fields' => array('Gotra.id', 'Gotra.gotra')));

			$data = '';

			if (!empty($gotras)) {

				$data .= '<select name="data[Member][other_gotra_id]" id="other_gotra_id" required="required" style="width:240px;">';
				$data .= "<option value=''>Select</option>";

				foreach ($gotras as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';

			}else{
				$data .= '<select name="data[Member][other_gotra_id]" id="other_gotra_id" required="required" style="width:240px;">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';
			}

			echo $data;
			exit;
		}
	}

}
