<?php 

App::uses('Component', 'Controller');

/**
* 
*/
class ExportXlsComponent extends Component
{
	
	public function export($fileName, $headerRow, $data){
		ini_set('max_execution_time', 1600);
		$fileContent = implode('\t', $headerRow).'\n';
		foreach ($data as $result) {
			$fileContent .= implode('\t', $result).'\n';
		}

		header('Content-type: application/ms-excel');
		header('Content-Disposition: attachment; filename='.$fileName);

		echo $fileContent;
		exit;
	}
}