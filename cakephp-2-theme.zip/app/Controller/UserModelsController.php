<?php
App::uses('AppController', 'Controller');
/**
 * UserModels Controller
 *
 * @property UserModel $UserModel
 * @property PaginatorComponent $Paginator
 */
class UserModelsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->UserModel->recursive = 0;
		$this->set('userModels', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->UserModel->exists($id)) {
			throw new NotFoundException(__('Invalid user model'));
		}
		$options = array('conditions' => array('UserModel.' . $this->UserModel->primaryKey => $id));
		$this->set('userModel', $this->UserModel->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->UserModel->create();
			if ($this->UserModel->save($this->request->data)) {
				$this->Flash->success(__('The user model has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The user model could not be saved. Please, try again.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->UserModel->exists($id)) {
			throw new NotFoundException(__('Invalid user model'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->UserModel->save($this->request->data)) {
				$this->Flash->success(__('The user model has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The user model could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('UserModel.' . $this->UserModel->primaryKey => $id));
			$this->request->data = $this->UserModel->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->UserModel->id = $id;
		if (!$this->UserModel->exists()) {
			throw new NotFoundException(__('Invalid user model'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->UserModel->delete()) {
			$this->Flash->success(__('The user model has been deleted.'));
		} else {
			$this->Flash->error(__('The user model could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
